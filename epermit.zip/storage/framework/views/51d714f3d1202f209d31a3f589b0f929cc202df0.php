<?php echo $__env->make("includes/header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<div class="container-fluid bdy dashboard">
    <div class="py-5 section">
        <div class="row">
            <div class="col-md-1"></div>
            <div class="card col-md-4">
                <h5 class="card-header">
                    <span>Create Market Fee</span>
                </h5>
                <?php if(isset($form)): ?>
                    <form action="<?php echo e(url('market_fee')); ?>/update" method="post">
                        <input type="hidden" name="id" value="<?php echo e($form[0]->id); ?>">
                <?php else: ?>
                    <form action="<?php echo e(url('market_fee')); ?>/add" method="post">
                <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Market Fee Percentage <span class="text-danger">*</span></label>
                                    <input name="percent" class="mfee form-control pri-form" value="<?php if(isset($form)): ?><?php echo e($form[0]->percent); ?><?php endif; ?>" required>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">From Date<span class="text-danger">*</span></label>
                                    <input type="date" class="fd form-control pri-form" name="from_date" value="<?php if(isset($form)): ?><?php echo e(explode(' ',$form[0]->from_date)[0]); ?><?php endif; ?>" required>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>To Date<span class="text-danger">*</span></label>
                                    <input type="date" class="td form-control pri-form" name="to_date" value="<?php if(isset($form)): ?><?php echo e(explode(' ',$form[0]->to_date)[0]); ?><?php endif; ?>" required>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <input type="submit" class="btn btn-info" value="submit">
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-md-1"></div>
            <div class="card col-md-5">
                <h5 class="card-header"><span>Market Fee List</span></h5>
                <div class="card-body" style="overflow: auto;">
                    <div class="row">
                        <style>
                            th,td { border: 2px solid black;    }
                        </style>
                        <table class="table theme-tbl table-bordered" style="text-align:center;">
                            <thead>
                                <tr>
                                    <th>Sl.</th>
                                    <th>Percentage</th>
                                    <th>From date</th>
                                    <th>To Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(isset($mfee)): ?>
                                <?php $i = 0; ?>
                                <?php $__currentLoopData = $mfee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $i=$i+1; ?>
                                <tr class="">
                                    <td class=""><?php echo e($i); ?></td>
                                    <td class=""><?php echo e($mf->percent); ?></td>
                                    <td class=""><?php echo e(explode(' ',$mf->from_date)[0]); ?></td>
                                    <td class=""><?php echo e(explode(' ',$mf->to_date)[0]); ?></td>
                                    <td class="">
                                     <a class="btn btn-info" href="<?php echo e(url('market_fee')); ?>/edit/<?php echo e($mf->id); ?>">Edit</a>   
                                     <a class="btn btn-info" href="<?php echo e(url('market_fee')); ?>/delete/<?php echo e($mf->id); ?>" onclick="return confirm('Are you Sure you want to delete?');" >Delete</a> </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-1"></div>
        </div>
    </div>
</div>
</div>
<?php if(session()->has('alert')): ?>
<script>
    alert("<?php echo e(session()->get('alert')); ?>");
</script>
<?php session()->forget('alert'); ?>
<?php endif; ?>
<?php echo $__env->make("includes/footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
</body>

</html><?php /**PATH C:\wamp64\www\temp2laravel\epermit\resources\views/mfee.blade.php ENDPATH**/ ?>