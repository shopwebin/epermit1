<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php if(isset($dat->c_status)): ?><?php if($dat->c_status == 2): ?><?php echo e($type); ?> Emergency <?php elseif($dat->c_status == 3): ?> Early Arrival of <?php echo e($type); ?> <?php elseif($dat->c_status == 0): ?> Cancellation of <?php echo e($type); ?> <?php endif; ?> <?php else: ?> <?php echo e($type); ?> <?php endif; ?> Permit</title>
    <style>
        body{font-family: Arial, Helvetica, sans-serif; font-size: 16px;}
        .table{width: 100%;}
        @media  print{
            input{
                border-width:0px;
                border:none;
                outline:none;
            }
        }
    </style>
</head>
<body>
    
    <div style="max-width: 1000px; margin: 30px auto; box-shadow: 1px 1px 30px #0003; padding: 20px;">
        <table border="0" cellpadding="0" cellspacing="0" class="table">
            <tr style="font-size: 12px;">
                <td></td>
                <td colspan="3"></td>
            </tr>
            <tr>
                <td colspan="4" style="padding: 10px;">
                    <table border="0" cellpadding="4" cellspacing="0" class="table">
                        <tr>
                            <td style="width: 25%;"><a href="<?php echo e(url('trade-list')); ?>"><img src="<?php echo e(url('images')); ?>/Secondary-Permit_06.png" alt="logo" style="width: 170px;" /></a></td>
                            <td style="text-align: center;width: 50%; font-size: 18px;">
                                The Andhra Pradesh Agricultural<br />
                                (Agri Produce & Livestock)<br />
                                Market Rules,1969<br />
                                Form-12<br />
                                [Rule 74 - A]<br />
                                E- Transport Permit For Transportation
                                of Notified Agricultural Produce
                            </td>
                            <td><img src="<?php echo e(url('images')); ?>/qrcode.png" alt="qrcode" style="width: 220px;" /></td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td style="width: 25%;">License Number:</td>
                <td style="width: 25%;"><?php echo e($dat->lic_no); ?></td>
                <td style="width: 25%;">Date and Time:</td>
                <td style="width: 25%;"><?php $mytime = Carbon\Carbon::now();
                    echo $mytime->toDateTimeString(); ?></td>
            </tr>
            <tr>
                <td>Permit Number:</td>
                <td><?php echo e($type[0]); ?><?php echo e($dat->id); ?></td>
                <td>Sale/Invoice No:</td>
                <td><?php if(!empty($dat->invoice)): ?><?php echo e($dat->invoice); ?><?php else: ?>
                    <input type="text" name="invoice"><?php endif; ?>
                </td>
            </tr>
            <tr>
                <td>Permit Type:</td>
                <td><?php if(isset($dat->c_status) &&  ($dat->c_status != 1)): ?>
                    <?php if($dat->c_status == 2): ?><?php echo e($type); ?> Emergency 
                    <?php elseif($dat->c_status == 3): ?> Early Arrival of <?php echo e($type); ?> 
                    <?php elseif($dat->c_status == 0): ?> Cancellation of <?php echo e($type); ?> <?php endif; ?> 
                    <?php else: ?> <?php echo e($type); ?> <?php endif; ?> Permit</td>
                <td></td>
                <td></td>
            </tr>
            <tr><td colspan="4"><hr /></td></tr>
            <tr>
                <td style="padding: 3px 0;">Firm Name:</td>
                <td style="padding: 3px 0;" colspan="3"><?php echo e($dat->firmname); ?></td>
            </tr>
            <tr>
                <td style="padding: 3px 0;">Address:</td>
                <td style="padding: 3px 0;" colspan="3"><?php echo e($dat->firmaddress); ?></td>
            </tr>
            <tr><td colspan="4"><hr /></td></tr>
            <tr>
                <td style="padding: 3px 0;">Seller Name:</td>
                <td style="padding: 3px 0;" colspan="3"><?php echo e($dat->tname); ?></td>
            </tr>
            <tr>
                <td style="padding: 3px 0;">Purchase Address:</td>
                <td style="padding: 3px 0;" colspan="3"><?php echo e($dat->address); ?></td>
            </tr>
            <tr><td colspan="4"><hr /></td></tr>
            <tr>
                <td style="padding: 3px 0;">Consignee Name:</td>
                <td style="padding: 3px 0;" colspan="3"><?php echo e($dat->name); ?></td>
            </tr>
            <tr>
                <td style="padding: 3px 0;">Address:</td>
                <td style="padding: 3px 0;" colspan="3"><?php echo e($dat->ad1); ?>,<?php echo e($dat->ad2); ?></td>
            </tr>
            <tr>
                <td style="padding: 3px 0;">Mobile no:</td>
                <td style="padding: 3px 0;" colspan="3"><?php if(isset($dat->mobile)): ?><?php echo e($dat->mobile); ?><?php else: ?>
            <input type="number"><?php endif; ?></td>
            </tr>
            <tr><td colspan="4"><hr/></td></tr>
            <!--tr>
                <td colspan="4">24,150.00</td>
            </tr-->
            <tr>
                <td>Commodity:</td>
                <td><?php echo e($dat->com_name); ?></td>
                <td>Quantity:</td>
                <td><?php echo e($dat->a_weight); ?>.00</td>
            </tr>
            <tr>
                <td>Sale value (INR):</td>
                <td><?php echo e($dat->value); ?>.00</td>
                <td>Quantity Type:</td>
                <td><?php echo e($dat->qty_name); ?></td>
            </tr>
            <tr>
                <td>Transport Vehicle:</td>
                <td><?php echo e($dat->veh_detail); ?></td>
                <?php if(isset($dat->c_qty) && ($dat->c_qty > 0)): ?>
                <td>Cancelled Quantity:</td>
                <td><?php echo e($dat->c_qty); ?>.00</td>
                <?php else: ?>
                <td></td>
                <td></td>
                <?php endif; ?>
            </tr>
            <tr><td colspan="4"><hr /></td></tr>
            <tr>
                <td colspan="4">Duration of the permit in force from <?php echo e($dat->valid_from); ?> PM <?php if(isset($dat->valid_to)): ?> to <?php echo e($dat->valid_to); ?>. <?php endif; ?> </td>
            </tr>
            
            <tr><td colspan="4"><hr /></td></tr>
            <tr>
                <td colspan="4">I declare that the information furnished above is true to the best of my knowledge & belief.</td>
            </tr>
            <tr><td colspan="4"><hr /></td></tr>
            <tr>
                <td colspan="4" style="text-align: right; padding-top: 50px;">Signature of Trader/Exporter</td>
            </tr>
            <tr>
                <!-- <td colspan="4" style="font-size: 12px; padding-top: 50px;">https://myap.e-pragati.in/prweb/sso1/uaWvF7nvxy_mi7mEeoM6lA%5B%5B*/!STANDARD?pyActivity=%40baseclass.pzTransformAndRun&pzTra</td> -->
            </tr>
        </table>
    </div>
</body>
</html><?php /**PATH C:\wamp64\www\temp2laravel\epermit\resources\views\secondary-permit.blade.php ENDPATH**/ ?>