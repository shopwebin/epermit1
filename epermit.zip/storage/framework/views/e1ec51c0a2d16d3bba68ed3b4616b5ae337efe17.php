<?php echo $__env->make("includes/header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<div class="container-fluid bdy dashboard">
    <div class="py-5 section">
        <div class="row">
        <div class="card  col-md-4">
            <h5 class="card-header">
                <span>Create Commodity</span>                
            </h5>
            <script>
                $(document).ready(function() {
                $('.form1').one('submit', function(e){
                    e.pervantDefault();
                    var t = $('.dt').val();
                    var f = $('.df').val();
                    var flag = 1;
                    if(t < f){
                        alert('kindly enter correct date');
                        flag= 0;
                    } else{
                        var name = upper($('.com_name').val());
                        /* var a = $com}};
                        a.each(function(index,value){
                            alert("$val->com_name}}"); */
                            <?php $__currentLoopData = $com; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                            
                            if(name == "<?php echo e($value->com_name); ?>"){
                            if(((t >= "<?php echo e($value->com_name); ?>")&&(t<="<?php echo e($value->com_name); ?>"))||((f >= "<?php echo e($value->com_name); ?>")&&(f<="<?php echo e($value->dt); ?>"))){
                                alert("date is already booked");
                                flag = 0
                            }}
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        // });
                        if(flag){
                            // $('.form1').submit();
                        }
                    }
                });
                });
            </script>
            <?php if(session()->has('alert')): ?>
                <script>
                    alert("<?php echo e(session()->get('alert')); ?>");
                </script>
            <?php session()->forget('alert'); ?>
            <?php endif; ?>
            <?php if(isset($dat)): ?>
                <form action="<?php echo e(url('commodity/update')); ?>" class="form1" method="post">
                    
                    <input type="hidden" name="com_id" value="<?php echo e($dat[0]->com_id); ?>">
            <?php else: ?>
                <form action="<?php echo e(url('commodity')); ?>/add" class="form1" method="post">
            <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Commodity <span class="text-danger">*</span></label>
                                <input type="" name="com_name" class="com_name form-control pri-form" value="<?php if(isset($dat)): ?><?php echo e($dat[0]->com_name); ?><?php endif; ?>" required>
                            </div>
                            </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Commodity discription <span class="text-danger">*</span></label>
                                <input type="" name="com_description" class="form-control pri-form" value="<?php if(isset($dat)): ?><?php echo e($dat[0]->com_description); ?><?php endif; ?>">
                            </div>
                            </div>
                            <div class="col-md-12">
                            <div class="form-group">
                                <label>Price<span class="text-danger">*</span></label>
                                <input type="" name="amt" class="form-control pri-form" value="<?php if(isset($dat)): ?><?php echo e($dat[0]->amt); ?><?php endif; ?>" required>
                            </div>
                            </div>
                            <div class="col-md-12">
                            <div class="form-group">
                                <label>Price valid from<span class="text-danger">*</span></label>
                                <input type="date" name="df" class="df form-control pri-form" value="<?php if(isset($dat)): ?><?php echo e($dat[0]->df); ?><?php endif; ?>" required>
                            </div>
                            </div>
                            <div class="col-md-12">
                            <div class="form-group">
                                <label>Till Date <span class="text-danger">*</span></label>
                                <input type="date" name="dt" class="dt form-control pri-form" value="<?php if(isset($dat)): ?><?php echo e($dat[0]->dt); ?><?php endif; ?>" required>
                            </div>
                            </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Quantity<span class="text-danger">*</span></label>
                                <select name="q_id" class="form-control pri-form" id="amc" required>
                                    <option value="">Select</option>
                                    <?php $__currentLoopData = $qty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($q->id); ?>"  <?php if(isset($dat)&&($dat[0]->q_id == $q->id)): ?><?php echo e("selected"); ?><?php endif; ?> ><?php echo e($q->qty_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            </div>
                        </div>
                    <div class="text-center">
                        <input type="submit" class="btn btn-info" name="submit" value="<?php if(isset($dat) ): ?><?php echo e('Update'); ?><?php else: ?><?php echo e('Add'); ?><?php endif; ?>" />
                    </div> 
                        <!--<div class="col-md-4">
                            <div class="form-group">
                                <label>State <span class="text-danger">*</span></label>
                                <select class="form-control pri-form state" name="state" class="">
                                    <option>Select</option>
                                    --}}
                                </select>
                            </div>
                        </div>
                    <div class="col-md-12">
                        <div class="form-check1">
                            <label class="pri-check">
                                <input type="checkbox"><i></i>
                                I declare that the information furnished above is true to best of my knoledge
                            </label>
                        </div>
                    </div>
                    <div class="text-center">
                        <a class="btn" href="javascript:helpModal('#pay-mode-modal')">Pay Market fee</a>
                        <input type="submit" class="btn btn-info" value="Pay Market Fee Later" />
                        <button type="button" class="btn btn-cancel" onclick="window.history.back()">Cancel</button>
                    </div> -->
                </div>
            </form>
        </div>
        <div class="col-md-1"></div>
        <div class="card col-md-7" style="height: 85vh;">
            <h5 class="card-header">
                <span>Commodity List</span>                
            </h5>
            <div class="card-body" style="overflow: auto;">
                <div class="row">
                    <style> th,td{  border:2px solid black; }   </style>
                    <table class="table theme-tbl table-bordered" style="text-align:center;">
                        <thead>
                            <tr>
                            <th>Sl. No.</th>
                            <th>Commodity</th>
                            <th>Description</th>
                            <th>Unit</th>
                            <th>Price</th>
                            <th>Valid From</th>
                            <th>Till Date</th>
                            <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 0; $cn='';  ?>
                            <?php $__currentLoopData = $com; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(($cn != $c->com_name) || ($i==0)): ?>
                                    <?php $i++; 
                                    $cn = $c->com_name; ?>
                            <tr data-toggle="collapse" data-target="#demo<?php echo e($i); ?>" class="accordion-toggle">
                                <td><button class="btn btn-default btn-xs"><?php echo e($i); ?></button></td>
                                <td><?php echo e($c->com_name); ?></td>
                                <td><?php echo e($c->com_description); ?></td>
                                <td><?php echo e($c->qty_name); ?></td>
                                <td><?php echo e($c->amt); ?></td>
                                <td><?php echo e($c->df); ?></td>
                                <td><?php echo e($c->dt); ?></td>
                                <td>
                                     <a class="btn btn-info" href="<?php echo e(url('commodity')); ?>/edit/<?php echo e($c->com_id); ?>">Edit</a>   
                                     <a class="btn btn-info" href="<?php echo e(url('commodity')); ?>/delete/<?php echo e($c->com_id); ?>"
                                      onclick="return confirm('Are you Sure you want to delete <?php echo e($c->com_name); ?> ?');" >Delete</a>   
                                </td>
                            </tr>
                            <?php else: ?>
                            <tr id="demo<?php echo e($i); ?>" class="hiddenRow accordian-body collapse">
                                <td></td>
                                <td><?php echo e($c->com_name); ?></td>
                                <td><?php echo e($c->com_description); ?></td>
                                <td><?php echo e($c->qty_name); ?></td>
                                <td><?php echo e($c->amt); ?></td>
                                <td><?php echo e($c->df); ?></td>
                                <td><?php echo e($c->dt); ?></td>
                                <td>
                                     <a class="btn btn-info" href="<?php echo e(url('commodity')); ?>/edit/<?php echo e($c->com_id); ?>">Edit</a>   
                                     <a class="btn btn-info" href="<?php echo e(url('commodity')); ?>/delete/<?php echo e($c->com_id); ?>" onclick="return confirm('Are you Sure you want to delete <?php echo e($c->com_name); ?> ?');" >Delete</a>   
                                </td>
                            </tr>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        </div>
    </div>
</div>
<?php echo $__env->make("includes/footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
</body>

</html><?php /**PATH C:\wamp64\www\temp2laravel\epermit\resources\views\commodity.blade.php ENDPATH**/ ?>