<?php echo $__env->make("includes/header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid bdy dashboard">
    <div class="py-5 section">
        <div class="card">
            <h5 class="card-header">
                <span>Trade Details</span>
                <!--div class="btn-grp">
                    <btn onclick="window.history.back()" title="Back"><i class="priya-arrow-left"></i></btn>
                    <btn onclick="" title="Dashboard"><i class="priya-dashboard"></i></btn>
                    <btn onclick="helpModal('#add-dist-help')" title="Help"><i class="priya-info"></i></btn>
                    <btn onclick="" title="History"><i class="priya-history"></i></btn>
                </div-->
            </h5>
            <?php if(session()->has('alert')): ?>
                <script>
                    alert("<?php echo e(session()->get('alert')); ?>");
                    <?php echo e(session()->forget('alert')); ?>

                </script>
            <?php endif; ?>
            <div class="card-body" style="overflow: auto;height: 75vh;">
                <table class="table theme-tbl table-bordered">
                    <thead>
                        <tr>
                            <th>Trade Id</th>
                            <th>Trade Type</th>
                            <th>AMC</th>
                            <th>Trade Date</th>
                            <th>Commodity</th>
                            <th>Purchase Quantity</th>
                            <th>Balance Quantity</th>
                            <th>Value (INR)</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $dat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $td): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                        
                            <?php $__currentLoopData = $td->trade_com; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php if($key == 0): ?>
                            <td rowspan="<?php echo e(count($td->trade_com)); ?>" data-id="<?php echo e($td->id); ?>" data-p_status="<?php echo e($td->id); ?>">T<?php echo e($td->id); ?></td>
                            <td rowspan="<?php echo e(count($td->trade_com)); ?>"><?php echo e($td->trade_type); ?></td>
                            <td rowspan="<?php echo e(count($td->trade_com)); ?>"><?php echo e($td->amc); ?></td>
                            <td rowspan="<?php echo e(count($td->trade_com)); ?>"><?php echo e(explode(' ',$td->created_at)[0]); ?></td>
                            <?php endif; ?>
                            <td><?php echo e($tc->cty); ?></td>
                            <td><?php echo e($tc->weight); ?></td>
                            <td><?php echo e($tc->a_weight); ?></td>
                            <td><?php echo e($tc->trade_value); ?></td>
                            <?php if($key == 0): ?>
                            <td rowspan="<?php echo e(count($td->trade_com)); ?>">
                                <?php if($td->p_status % 2 == 0): ?>
                                    <button data-id="<?php echo e($td->id); ?>" type="button" class="btn btn-info pay" onclick="helpModal('#pay-mode-modal')">Pay Fee</button>
                                <?php else: ?>
                                    <button class="btn btn-info">Paid</button>
                                <?php endif; ?>
                                
                                <?php if(($td->trade_type != 'Stock') && ($td->p_status % 2 != 0)): ?>
                                <?php if(($td->a_weight >0)): ?>
                                    <?php if(isset($td->permit_id)): ?>
                                        <a href="secondary-permit-creation/T<?php echo e($td->id); ?>" class="btn btn-info">Create Secondary Permit</a>
                                        
                                    <?php else: ?>
                                        <a href="permit-creation/T<?php echo e($td->id); ?>" class="btn btn-info">Create Permit</a>
                                    <?php endif; ?>
                                <?php endif; ?>
                                    <?php if($td->p_status > 2): ?> 
                                        <?php $__currentLoopData = $td->sec; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                      
                                            <a href="secondary-permit-creation/S<?php echo e($sec->id); ?>" class="btn btn-info">Edit Permit-S<?php echo e($sec->id); ?></a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    <?php if(isset($td->permit_id)): ?>
                                        <a href="permit-creation/P<?php echo e($td->permit_id); ?>" class="btn btn-info">Edit Permit-P<?php echo e($td->permit_id); ?></a>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($td->p_status % 2 != 0): ?>
                                    <a href="edit-trade/T<?php echo e($td->id); ?>" class="btn btn-info">Edit Trade</a>
                                <?php endif; ?>
                            </td><?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <a href="new-trader-creation" title="Add Other Users" class="float-btn"> + </a>
</div>
<?php echo $__env->make("includes/footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="pay-mode-modal" class="help-modal" style="display: none;">
    <div class="help-modal-content pop-md">
        <i class="priya-close" onclick="helpModalHide(this)"></i>
        <header>Select Payment Gateway</header>
        <section>
            <div class="row">
                <div class="col-md-6">
                    <h3>SBI Charges</h3>
                    <ul>
                        <li>    Net Banking:
                            <ul>
                                <li>SBI Bank Charges: 11.8</li>
                                <li>Other Banks - Bank Charges: 17.7</li>
                            </ul>
                        </li>
                        <li>    Card Payments:
                            <ul>
                                <li>State Bank Debit Cards - Bank Charges: Nill</li>
                                <li>Other Bank Debit Cards - Bank Charges: Nill</li>
                                <li>Credit Cards - Bank Charges: 12.99</li>
                            </ul>
                        </li>
                    </ul>
                    <button type="button" class="btn btn-info payfee" onclick="sub()">SBI</button>
                </div>
                <div class="col-md-6">
                    <h3>PAYU Charges</h3>
                    <ul>
                        <li>Credit Cards(VISA/MasterCard): 1% per transaction</li>
                        <li>Debit Cards(VISA/MasterCard/RuPay/Maestro): 0% below INR 2000 and 0.9% above INR 2000</li>
                        <li>Net Banking: INR 11 per transaction.</li>
                        <li>UPI: INR 12 per transaction</li>
                        <li>Taxes as applicable</li>
                    </ul>
                    <button type="button" class="btn btn-info payfee" onclick="sub()">PAYU</button>
                </div>
            </div>
        </section>
    </div>
</div>
<script>
    $('.pay').click(function(){
        $('.payfee').attr('onclick','sub('+$(this).attr('data-id')+')');
    });
    function sub(id){
        $.ajax({
            type:'GET',
            url:'<?php echo e(url("pay")); ?>/'+id,
            success:function(result){
                alert("Paid successfull for trade No."+id);
                location.reload();
            }
        });
    }
</script>
</body>
</html>
<!-- </td>
    <td><?php echo e($td->a_weight); ?> </td>
    <td>Rs <?php echo e($td->trade_value --); ?></td> 
     $td->cty = '';
    $td->weight = 0;
    $td->a_weight = 0;
    $td->trade_value = 0;
    $cq=[];
    $acq=[];
    $q=[];
    $cty = [''];
    foreach($td->trade_com as $tc){
        if(!in_array($tc->cty,$cty)){
            $cty[] = $tc->cty;
        }
        // $td->cty .= ','.$tc->cty;
        $td->trade_value+=$tc->trade_value;
        if(!isset($q[$tc->q_id])){
            $q[$tc->q_id]=$cq[$tc->q_id]=$acq[$tc->q_id] = 0;
        }
        $acq[$tc->q_id]+=$tc->a_weight;
        $cq[$tc->q_id]+=$tc->weight;
        $q[$tc->q_id]=$tc->qty;
    }
    $td->weight='';
    $td->a_weight='';
    foreach($q as $key=>$q1){
        $td->weight .= ",".$cq[$key].$q1;
        $td->a_weight .= ",".$acq[$key].$q1;
    }                            
    $td->cty = join(",",$cty);
    $td->cty = substr($td->cty,1);
    $td->weight = substr($td->weight,1);
    $td->a_weight = substr($td->a_weight,1);
--><?php /**PATH C:\wamp64\www\temp2laravel\epermit\resources\views/trade-list.blade.php ENDPATH**/ ?>